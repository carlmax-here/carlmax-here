## <h1 align="center">Hi! 👋 I'm Gokul Bijoy</h1>

- 🔭 I’m currently working on Nothing!
- 🌱 I’m currently learning Everything I want! 😅
- 👯 I’m looking to collaborate on 😒😑
- 🤔 I’m looking for help with Python
- 💬 Ask me about Anything 😒🤖😑
- 📫 How to reach me [See Here](https://t.me/carlmax_here#contact-me)

<p align="center">
  <a href="https://t.me/telegram.dog/carlmax_here"><img src="https://user-images.githubusercontent.com/77770753/117139498-f081c400-adc9-11eb-9aaf-f895a54ecc67.gif"></a>
    </p>
<h3>

## Profile,
<p align="center">
<a href="https://www.instagram.com/__simmo_____"><img alt="Instagram" src="https://img.shields.io/badge/Gokul Bijoy-%23E4405F.svg?&style=for-the-badge&logo=Instagram&logoColor=white"/></a>
<a href="https://t.me/carlmax_here"><img alt="Telegram" src="https://img.shields.io/badge/Gokul Bijoy-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"/></a>
</p>

# Contact Me

<a href="https://t.me/cinemapedika"><img src="https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white"></a>
                                                                                                                                       
# Stats

![Hirusha-H's GitHub stats](https://github-readme-stats.vercel.app/api?username=carlmax-here&show_icons=true&theme=tokyonight)
